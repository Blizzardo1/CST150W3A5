﻿using System.Windows.Forms;

namespace CST150W3A5 {
    partial class Form1 {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && ( components != null )) {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.outputTxt = new TextBox();
            this.openBtn = new Button();
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Text = "Week 3 Assignment 5";
            this.SuspendLayout();
            ///
            /// outputTxt
            /// 
            this.outputTxt.Size = new(782, 250);
            this.outputTxt.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            this.outputTxt.Multiline = true;
            this.outputTxt.Location = new(9, 12);
            this.outputTxt.Name = "outputTxt";
            ///
            /// openBtn
            /// 
            this.openBtn.Size = new(75, 23);
            this.openBtn.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.openBtn.Location = new(9, 266);
            this.openBtn.Name = "openBtn";
            this.openBtn.Text = "Open...";
            this.openBtn.Click += OpenBtnOnClick;
            this.Controls.AddRange(new Control[] { this.outputTxt, this.openBtn });
            this.ResumeLayout(false);
        }

        #endregion

        private TextBox outputTxt;
        private Button openBtn;
    }
}